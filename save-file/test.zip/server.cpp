//many bugs...
//oh shit
#include<bits/stdc++.h>
#include<windows.h>
#include<thread>
#include<winsock2.h>
#include<ws2tcpip.h>
#define rep(i,x,y) for(int i=(x);i<=(y);++i)
#define eb emplace_back

//#pragma comment(lib,"Ws2_32.lib")
using namespace std;
vector<SOCKET> socks;
SOCKET clientSock;
int port;

enum TYPE{
	none=0,
	XX=1,
	OO=2,
	xj=3,
	jamie=4,
	tower=5,
	king=6
};
struct node{
	TYPE tp;
	int hp,maxhp,arm;
	int reg,pos,str,weak,ero,rid;
}g[5][3];
bool now=0;
string info[1024],name[1024];
int cost[1024];
SOCKET X,O;
int Xcnt,Ocnt,Xe,Oe,Xres,Ores;
vector<int> used,heap;
vector<int> Xc,Oc;

BOOL WINAPI ConsoleHandlerRoutine(DWORD dwCtrlType) {
    switch (dwCtrlType) {
        case CTRL_SHUTDOWN_EVENT:{
        	char data[1024];
        	data[0]='Q';
        	for(int i = 0;i < socks.size();i++){
				send(socks[i],data,1024,0);
			}
        	return TRUE;
		}
        default:
            return FALSE;
    }
} 
inline int toint(string x){
	stringstream sstream;
	sstream<<x;
	int ret;
	sstream>>ret;
	return ret;
}
inline void init(){
	fstream file;
	file.open("card.txt",ios::in|ios::binary);
	if(file.is_open()){
		int cnt=1;
		int flag=0;
		while(1){
			string s;
			if(!getline(file,s))break;
			while(s.back()=='\r')s.pop_back();
//			cout<<"read: ["<<s<<"]\n";
			if(s=="end"){
				++cnt;flag=0;continue;
			}else if(s=="name"){
				flag=1;continue;
			}else if(s=="cost"){
				flag=2;continue;
			}
			if(flag==0){
				name[cnt]=s;
			}else if(flag==1){
				cost[cnt]=toint(s);
			}else{
				s+='\n'; 
				info[cnt]+=s;
			}
//			cout<<name[cnt]<<"\n";
		}
	}
	file.close();
}
inline char check(){
	cout<<"Xres:"<<Xres<<",Ores:"<<Ores<<"\n";
	int Xall=Xres,Oall=Ores;
	rep(i,1,3){
		rep(j,0,2){
			if(g[i][j].tp==XX)++Xall;
			else if(g[i][j].tp==OO)++Oall;
		}
	}
	if(Xall<3&&Oall<3){
		char data[1024];
		data[0]='b';
		send(X,data,1024,0);
		send(O,data,1024,0);
	}else{
		char data[1024];
		data[0]='c';
		send(X,data,1024,0);
		send(O,data,1024,0);
	}
	if(Xall==0&&Oall==0)return 'D';
	else if(Xall==0&&Oall!=0)return 'O';
	else if(Xall!=0&&Oall==0) return 'X';
	if(g[1][0].tp==g[2][1].tp&&g[2][1].tp==g[3][2].tp&&g[1][0].tp!=none)return g[1][0].tp==XX?'X':'O';
	if(g[1][0].tp==g[1][1].tp&&g[1][1].tp==g[1][2].tp&&g[1][0].tp!=none)return g[1][0].tp==XX?'X':'O';
	if(g[2][0].tp==g[2][1].tp&&g[2][1].tp==g[2][2].tp&&g[2][0].tp!=none)return g[2][0].tp==XX?'X':'O';
	if(g[3][0].tp==g[3][1].tp&&g[3][1].tp==g[3][2].tp&&g[3][0].tp!=none)return g[3][0].tp==XX?'X':'O';
	if(g[1][0].tp==g[2][0].tp&&g[2][0].tp==g[3][0].tp&&g[1][0].tp!=none)return g[1][0].tp==XX?'X':'O';
	if(g[1][1].tp==g[2][1].tp&&g[2][1].tp==g[3][1].tp&&g[1][1].tp!=none)return g[1][1].tp==XX?'X':'O';
	if(g[1][2].tp==g[2][2].tp&&g[2][2].tp==g[3][2].tp&&g[1][2].tp!=none)return g[1][2].tp==XX?'X':'O';
	if(g[1][2].tp==g[2][1].tp&&g[2][1].tp==g[3][0].tp&&g[1][2].tp!=none)return g[1][2].tp==XX?'X':'O';
	return '?';
}
inline void hurt(int x,int y,int h){
	if(g[x][y].tp==none)return; 
	if(g[x][y].arm>=h)g[x][y].arm-=h,h=0;
	else h-=g[x][y].arm,g[x][y].arm=0;
	if(g[x][y].hp>h)g[x][y].hp-=h;
	else g[x][y].tp={none};
}
inline void take_card(SOCKET sock){
	if(sock==X&&Xcnt==10)return;
	if(sock==O&&Ocnt==10)return;
	if(heap.empty()){
		heap.swap(used);
		mt19937 rd(time(0));
		shuffle(heap.begin(),heap.end(),rd);
	}
	int x=heap.back();
	heap.pop_back();
	cout<<sock<<" get "<<x<<"\n"; 
	char send_data[1024];
	send_data[0]='a';
	memcpy(send_data+1,&x,4);
	send(sock,send_data,1024,0);
	if(sock==X)++Xcnt,Xc.eb(x);
	if(sock==O)++Ocnt,Oc.eb(x);
}
inline bool CHECK(){
	char data[1024];
	char c=check();
	cout<<"check:"<<c<<"\n";
	if(c!='?'){
		if(c=='X'){
			data[0]='E';
			for(int i = 0;i < socks.size();i++){
				if(socks[i]==X){
					data[1]='W';
					send(socks[i],data,1024,0);
				}else if(socks[i]==O){
					data[1]='L';
					send(socks[i],data,1024,0);
				}else{
					data[1]='X';
					send(socks[i],data,1024,0);
				}
			}
		}else if(c=='O'){
			data[0]='E';
			for(int i = 0;i < socks.size();i++){
				if(socks[i]==X){
					data[1]='L';
					send(socks[i],data,1024,0);
				}else if(socks[i]==O){
					data[1]='W';
					send(socks[i],data,1024,0);
				}else{
					data[1]='O';
					send(socks[i],data,1024,0);
				}
			}
		}else{
			data[0]='E';
			for(int i = 0;i < socks.size();i++){
				if(socks[i]==X){
					data[1]='D';
					send(socks[i],data,1024,0);
				}else if(socks[i]==O){
					data[1]='D';
					send(socks[i],data,1024,0);
				}else{
					data[1]='D';
					send(socks[i],data,1024,0);
				}
			}
		}
		cout<<"restart\n";
		rep(i,0,4){
			rep(j,0,2){
				g[i][j]={none};
			}
		}
		X=O=0;
		now=0;
		for(int i = 0;i < socks.size();i++){
			data[0]='Q';
			send(socks[i],data,1024,0);
		}
		socks.clear();
		return 1;
	}
	return 0;
}
inline void SAVE(){
	char data[1024];
	data[0]='U'; 
	memcpy(data+1,g,sizeof(g));
	for(int i = 0;i < socks.size();i++){
		send(socks[i],data,1024,0);
	}
}
inline void use_card(SOCKET sock,int card,int id,const vector<int>& arg){
	if(sock==X)Xe-=cost[card];
	else Oe-=cost[card];
	char data[1024];
	for(int i = 0;i < socks.size();i++){
		if(socks[i]==sock)continue;
		data[0]='r';
		if(sock==X)data[1]='X';
		else data[1]='O';
		memcpy(data+2,&card,4);
		send(socks[i],data,1024,0);
	}
	if(sock==X)--Xcnt,Xc.erase(Xc.begin()+id);
	if(sock==O)--Ocnt,Oc.erase(Oc.begin()+id);
	used.eb(card); 
	if(card==1){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].reg=3;
	}else if(card==2){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		mt19937 rd(time(0));
		int pd=rd()&1;
		if(pd){
			hurt(x-1,y-1,10);
			data[0]='m';
			const char str[]="�ж��ɹ���";
			memcpy(data+1,str,sizeof(str));
			send(sock,data,1024,0);
		}else{
			hurt(x-1,y-1,2);
			data[0]='m';
			const char str[]="�ж�ʧ�ܣ�";
			memcpy(data+1,str,sizeof(str));
			send(sock,data,1024,0);
		}
	}else if(card==3){
		if(used.size()==1)return;
		mt19937 rd(time(0));
		int x=rd()%(used.size()-1);
		data[0]='a';
		int tmp=used[x];
		used.erase(used.begin()+x);
		memcpy(data+1,&tmp,4);
		send(sock,data,1024,0);
		if(sock==X)++Xcnt,Xc.eb(tmp);
		else ++Ocnt,Oc.eb(tmp);
	}else if(card==4){
		int x=arg[0],y=arg[1];
		int Xall=Xres,Oall=Ores;
		rep(i,1,3){
			rep(j,0,2){
				if(g[i][j].tp==XX)++Xall;
				else if(g[i][j].tp==OO)++Oall;
			}
		}
		if(sock==X&&Xall==6)return;
		if(sock==O&&Oall==6)return;
		if(sock==X)g[x-1][y-1]={XX,4,4};
		else g[x-1][y-1]={OO,4,4};
	}else if(card==6){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		hurt(x-1,y-1,4);
	}else if(card==7){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1]={xj,4,4};
	}else if(card==8){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1]={jamie,10,10};
	}else if(card==9){
		if(sock==X&&Ocnt==0)return;
		if(sock==O&&Xcnt==0)return;
		if(sock==X){
			auto it=find(Oc.begin(),Oc.end(),13);
			if(it!=Oc.end()){
				data[0]='d';--Ocnt;
				int tmp=it-Oc.begin();
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
				data[0]='m';
				const char str[]="����ʧ�ܣ������ֵ���";used.eb(13);
				memcpy(data+1,&str,sizeof(str));
				send(X,data,1024,0);
				const char st[]="����TAʧ���ˡ�";
				memcpy(data+1,&st,sizeof(st));
				for(int i = 0;i < socks.size();i++){if(socks[i]!=sock)send(socks[i],data,1024,0);}
				return;
			}
		}else{
			auto it=find(Xc.begin(),Xc.end(),13);
			if(it!=Xc.end()){
				data[0]='d';--Xcnt;
				int tmp=it-Xc.begin();
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				data[0]='m';
				const char str[]="����ʧ�ܣ������ֵ���";used.eb(13);
				memcpy(data+1,&str,sizeof(str));
				send(O,data,1024,0);
				const char st[]="����TAʧ���ˡ�";
				memcpy(data+1,&st,sizeof(st));
				for(int i = 0;i < socks.size();i++){if(socks[i]!=sock)send(socks[i],data,1024,0);}
				return;
			}
		}
		mt19937 rd(time(0));
		int x;
		if(sock==X)x=rd()%Ocnt;
		else x=rd()%Xcnt;
		int CARD;
		if(sock==X)CARD=Oc[x];
		else CARD=Xc[x];
		data[0]='a';
		memcpy(data+1,&CARD,4);
		send(sock,data,1024,0);
		if(sock==X)++Xcnt,Xc.eb(CARD);
		else ++Ocnt,Oc.eb(CARD);
		data[0]='d';
		memcpy(data+1,&x,4);
		if(sock==X)send(O,data,1024,0);
		else send(X,data,1024,0);
		if(sock==X)--Ocnt,Oc.erase(Oc.begin()+x);
		else --Xcnt,Xc.erase(Xc.begin()+x);
	}else if(card==10){
		rep(i,0,4){
			rep(j,0,2){
				if(g[i][j].tp!=none)hurt(i,j,10);
			}
		}
	}else if(card==11){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].hp+=3;
		g[x-1][y-1].hp=min(g[x-1][y-1].hp+3,g[x-1][y-1].maxhp);
	}else if(card==12){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].arm+=3;
	}else if(card==14){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].pos=3;
	}else if(card==15){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].rid=1;
	}else if(card==16){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1].pos=g[x-1][y-1].ero=g[x-1][y-1].reg=g[x-1][y-1].rid=g[x-1][y-1].str=g[x-1][y-1].weak=0;
	}else if(card==17){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		g[x-1][y-1]={tower,10,10};
	}else if(card==18){
		if(sock==X)Xe+=5;
		else Oe+=5; 
		data[0]='g';
		int tmp=5;
		memcpy(data+1,&tmp,4);
		send(sock,data,1024,0);
	}else if(card==19){
		cout<<"Xe:"<<Xe<<",Oe:"<<Oe<<"\n";
		if(sock==X&&Oe==0)return;
		if(sock==O&&Xe==0)return;
		if(sock==X){
			auto it=find(Oc.begin(),Oc.end(),13);
			if(it!=Oc.end()){
				data[0]='d';--Ocnt;
				int tmp=it-Oc.begin();
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
				data[0]='m';
				const char str[]="���ֵ���";used.eb(13);
				memcpy(data+1,&str,sizeof(str));
				send(X,data,1024,0);
				const char st[]="����TAʧ���ˡ�";
				memcpy(data+1,&st,sizeof(st));
				for(int i = 0;i < socks.size();i++){if(socks[i]!=sock)send(socks[i],data,1024,0);}
				return;
			}
		}else{
			auto it=find(Xc.begin(),Xc.end(),13);
			if(it!=Xc.end()){
				data[0]='d';--Xcnt;
				int tmp=it-Xc.begin();
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				data[0]='m';
				const char str[]="���ֵ���";used.eb(13);
				memcpy(data+1,&str,sizeof(str));
				send(O,data,1024,0);
				const char st[]="����TAʧ���ˡ�";
				memcpy(data+1,&st,sizeof(st));
				for(int i = 0;i < socks.size();i++){if(socks[i]!=sock)send(socks[i],data,1024,0);}
				return;
			}
		}
		if(sock==X){
			if(Oe>=5){
				Oe-=5;
				Xe+=5;
				data[0]='g';
				int tmp=5;
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				data[0]='p';
				tmp=5;
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
			}else{
				Xe+=Oe;
				data[0]='g';
				int tmp=Oe;
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				data[0]='p';
				tmp=Oe;
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
				Oe=0;
			}
		}else{
			if(Xe>=5){
				Xe-=5;
				Oe+=5;
				data[0]='g';
				int tmp=5;
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
				data[0]='p';
				tmp=5;
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
			}else{
				Oe+=Xe;
				data[0]='g';
				int tmp=Xe;
				memcpy(data+1,&tmp,4);
				send(O,data,1024,0);
				data[0]='p';
				tmp=Xe;
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				Xe=0;
			}
		}
	}else if(card==20){
		int x=arg[0],y=arg[1];
		if(x==0&&y==0)return;
		hurt(x-1,y-1,3);
		hurt(x-1,y,3);
		hurt(x,y-1,3);
		hurt(x,y,3);
	}else if(card==21){
		if(sock==X)Xe+=5;
		else Oe+=5; 
		data[0]='g';
		int tmp=5;
		memcpy(data+1,&tmp,4);
		send(sock,data,1024,0);
	}
	SAVE();
}
void user(SOCKET sock){
	init();
	char recv_data[1024],data[1024];
	while(recv(sock,recv_data,1024,0) > 0){
		if(recv_data[0]=='L'){
			cout<<"Left\n";
			if(sock==X){
				data[0]='E';
				for(int i = 0;i < socks.size();i++){
					data[1]='f';
					send(socks[i],data,1024,0);
				}
			}else if(sock==O){
				data[0]='E';
				for(int i = 0;i < socks.size();i++){
					data[1]='f';
					send(socks[i],data,1024,0);
				}
			}
			if(find(socks.begin(),socks.end(),sock)==socks.end())return;
			cout<<"count:"<<socks.size()-1<<'\n';
		}else if(recv_data[0]=='J'){
			cout<<"Join\n";
			cout<<"count:"<<socks.size()<<'\n';
			if(socks.size()>2&&sock!=X&&sock!=O){
				data[0]='U'; 
				memcpy(data+1,g,sizeof(g));
				send(sock,data,1024,0);
				data[0]='V';
				send(sock,data,1024,0);
				continue;
			}
			if(socks.size()==2){
				bool flag=1;
				cout<<"start\n";
				rep(i,0,4){
					rep(j,0,2){
						g[i][j]={none};
					}
				} 
				heap.clear(),used.clear();
				rep(i,1,21){
					if(i==1)heap.eb(1),heap.eb(1);
					else if(i==6)heap.eb(6),heap.eb(6);
					else if(i==7)heap.eb(7),heap.eb(7);
					else if(i==11)heap.eb(11),heap.eb(11);
					else if(i==12)heap.eb(12),heap.eb(12);
					else if(i==14)heap.eb(14),heap.eb(14);
					else if(i==21)heap.eb(21),heap.eb(21),heap.eb(21);
					else heap.eb(i);
				}
				mt19937 rd(time(0));
				shuffle(heap.begin(),heap.end(),rd);
				Xcnt=Ocnt=Xe=Oe=0;
				Xres=Ores=6;
				for(int i = 0;i < socks.size();i++){
//					if(socks[i] == sock) continue;
					data[0]='S';
					if(flag){
						X=socks[i];
						data[1]='X',flag=0;
					}else{
						O=socks[i];
						data[1]='O';
					}
					send(socks[i],data,1024,0);
					data[0]='U'; 
					memcpy(data+1,g,sizeof(g));
					send(socks[i],data,1024,0);
				}
				rep(i,1,5){
					take_card(X);
					take_card(O);
				}
				Xe=Oe=1;
				data[0]='g';
				int tmp=1;
				memcpy(data+1,&tmp,4); 
				send(X,data,1024,0);
				send(O,data,1024,0);
				cout<<"X:"<<X<<"\n"; 
				data[0]='Y';
				if(send(X,data,1024,0)==SOCKET_ERROR){
					X=0;
					for(int i = 0;i < socks.size();i++){
						data[1]='f';
						send(socks[i],data,1024,0);
					}
				}
				data[0]='O';
				if(send(O,data,1024,0)==SOCKET_ERROR){
					O=0;
					for(int i = 0;i < socks.size();i++){
						data[1]='f';
						send(socks[i],data,1024,0);
					}
				}
			} 
		}else if(recv_data[0]=='x'){
			if(sock==X)--Xres;
			else --Ores;
		}else if(recv_data[0]=='F'){
			if(sock==O){
				for(int i = 0;i < socks.size();i++){
					if(socks[i]==X){
						data[1]='W';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="����Ͷ���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}else if(socks[i]==O){
						data[1]='L';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="��Ͷ���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}else{
						data[1]='X';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="O���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}
				}
			}else{
				for(int i = 0;i < socks.size();i++){
					if(socks[i]==X){
						data[1]='L';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="��Ͷ���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}else if(socks[i]==O){
						data[1]='W';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="����Ͷ���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}else{
						data[1]='O';
						send(socks[i],data,1024,0);
						data[0]='m';
						const char str[]="X���ˣ�";
						memcpy(data+1,str,sizeof(str));
						send(socks[i],data,1024,0);
					}
				}
			}
		}else if(recv_data[0]=='U'){
			memcpy(g,recv_data+1,sizeof(g));
			data[0]='U';
			memcpy(data+1,g,sizeof(g));
			for(int i = 0;i < socks.size();i++){
				send(socks[i],data,1024,0);
			}
			if(CHECK())return;
		}else if(recv_data[0]=='e'){
			now^=1;
			if(now==0){
				rep(i,0,4){
					rep(j,0,2){
						if(g[i][j].tp==none)continue;
						int sum=0;
						if(g[i][j].pos){
							--sum;
							--g[i][j].pos;
						}
						if(g[i][j].ero){
							sum-=2;
							--g[i][j].ero;
						}
						if(g[i][j].reg){
							++sum;
							--g[i][j].reg;
						}
						if(g[i][j].weak){
							--g[i][j].weak;
						}
//						cout<<i<<","<<j<<":"<<sum<<"\n";
						if(sum<0){
							if(g[i][j].hp>-sum)g[i][j].hp+=sum;
							else g[i][j].tp=none;
						}else{
							g[i][j].hp+=sum;
							if(g[i][j].hp>g[i][j].maxhp)g[i][j].hp=g[i][j].maxhp;
						}
					}
				}
				data[0]='U';
				memcpy(data+1,g,sizeof(g));
				for(int i = 0;i < socks.size();i++){
					send(socks[i],data,1024,0);
				}
				if(CHECK())return;
				take_card(X),take_card(O);
				++Xe,++Oe;
				data[0]='g';
				int tmp=1;
				memcpy(data+1,&tmp,4);
				send(X,data,1024,0);
				send(O,data,1024,0);
				rep(i,0,4){
					rep(j,0,2){
						if(g[i][j].tp==xj){
							if(i==0)send(X,data,1024,0);
							else if(i==4)send(O,data,1024,0);
						}
					}
				}
			}
			if(now){
				cout<<"O:"<<O<<'\n';
				for(int i = 0;i < socks.size();i++){
					if(socks[i]==X){
						data[0]='O';
						send(socks[i],data,1024,0);
					}else if(socks[i]==O){
						data[0]='Y';
						send(socks[i],data,1024,0);
					}else{
						data[0]='V';
						send(socks[i],data,1024,0);
					}
				}
			}else{
				cout<<"X:"<<X<<"\n";
				for(int i = 0;i < socks.size();i++){
					if(socks[i]==X){
						data[0]='Y';
						send(socks[i],data,1024,0);
					}else if(socks[i]==O){
						data[0]='O';
						send(socks[i],data,1024,0);
					}else{
						data[0]='V';
						send(socks[i],data,1024,0);
					}
				}
			}
		}else if(recv_data[0]=='u'){
			vector<int> tmp;
			tmp.clear();
			int x,y;
			memcpy(&x,recv_data+1,4);
			memcpy(&y,recv_data+5,4);
			int cnt;
			memcpy(&cnt,recv_data+9,4);
			cout<<"cnt:"<<cnt<<"\n";
			for(int add=13;add<=13+(cnt-1)*4;add+=4){
				int ttt;
				memcpy(&ttt,recv_data+add,4);
				tmp.eb(ttt);
				cout<<"arg:"<<ttt<<"\n";
			}
			use_card(sock,x,y,tmp);
			if(CHECK())return;
		}else if(recv_data[0]=='m'){
			for(int i = 0;i < socks.size();i++){
				if(socks[i]==sock)continue;
				send(socks[i],recv_data,1024,0);
			}
		}else if(recv_data[0]=='j'){
			int type,sx,sy;
			memcpy(&type,recv_data+1,4);memcpy(&sx,recv_data+1015,4);memcpy(&sy,recv_data+1019,4);
			if(type==1){
				int fl,x;
				memcpy(&fl,recv_data+5,4);
				memcpy(&x,recv_data+9,4);
				if(fl==1){
					if(sock==X&&x==1)continue;
					else if(sock==O&&x==5)continue;
					rep(j,0,2){
						if((sock==X&&g[x-1][j].tp==XX)||(sock==O&&g[x-1][j].tp==OO))continue;
						hurt(x-1,j,max(0,3-(g[sx-1][sy-1].weak>0)+g[sx-1][sy-1].str));
					}
				}else if(fl==2){
					rep(i,0,4){
						if(sock==X&&i==0)continue;
						else if(sock==O&&i==4)continue;
						if((sock==X&&g[i][x-1].tp==XX)||(sock==O&&g[i][x-1].tp==OO))continue;
						hurt(i,x-1,max(0,3-(g[sx-1][sy-1].weak>0)+g[sx-1][sy-1].str));
					} 
				}
			}else if(type==2){
				int x,y;
				memcpy(&x,recv_data+5,4);memcpy(&y,recv_data+9,4);
				g[x-1][y-1].ero=3;
			}else if(type==3){
				int x,y;
				memcpy(&x,recv_data+5,4);memcpy(&y,recv_data+9,4);
				hurt(x-1,y-1,max(0,4-(g[sx-1][sy-1].weak>0)+g[sx-1][sy-1].str));
			}
			SAVE();
			if(CHECK())return;
		}else if(recv_data[0]=='t'){
			int sx,sy,x,y;
			memcpy(&sx,recv_data+1015,4);memcpy(&sy,recv_data+1019,4);
			memcpy(&x,recv_data+1,4);memcpy(&y,recv_data+5,4);
			hurt(x-1,y-1,max(0,3-(g[sx-1][sy-1].weak>0)+g[sx-1][sy-1].str));
			SAVE();
			if(CHECK())return;
		}
	}
	socks.erase(find(socks.begin(),socks.end(),sock));
	closesocket(sock);
}

int main(){
	if (!SetConsoleCtrlHandler(ConsoleHandlerRoutine, TRUE)){
		MessageBox(NULL,"����","��",MB_ICONERROR);return 0;
	}
	WSADATA wsa_data;
	WSAStartup(MAKEWORD(2,2),&wsa_data);
	SOCKET sock = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	cout<<"������IP��";
	
	char hostname[256],ip[256];
    int ret = gethostname(hostname, sizeof(hostname));
    if (ret != SOCKET_ERROR){
        HOSTENT* host = gethostbyname(hostname);
        if (host != NULL)
        {
            strcpy(ip, inet_ntoa(*(in_addr*)*host->h_addr_list)); 
        }
    }
    cout<<ip<<'\n';
	
	cout<<"�˿ڣ�"<<endl;
	cin>>port;
	server_addr.sin_port = htons(port);
	server_addr.sin_addr.s_addr = INADDR_ANY;
	if(bind(sock,(sockaddr*)&server_addr,sizeof(server_addr)) == SOCKET_ERROR){
		cerr<<"��!"<<endl;
		system("pause");
		return -1;
	}
	listen(sock,100);
	while(true){
		sockaddr_in client_addr;
		int client_addr_len = sizeof(client_addr);
		SOCKET client_sock = accept(sock,(sockaddr*)&client_addr,&client_addr_len);
		socks.push_back(client_sock);
		thread t(user,client_sock);
		t.detach();
	}
}
