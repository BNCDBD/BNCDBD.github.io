//Add Jamie!!!
#include<bits/stdc++.h>
#include<windows.h>
#include <graphics.h>
#include<thread>
#include<winsock2.h>
#include<ws2tcpip.h>
#pragma comment(lib,"Ws2_32.lib")
#define rep(i,x,y) for(int i=(x);i<=(y);++i)
#define eb emplace_back 

#define XW 50
#define WIDTH 100
#define ADD 7

using namespace std;

string addr;
int port;
SOCKET sock;

enum TYPE{
	none=0,
	XX=1,
	OO=2,
	xj=3,
	jamie=4,
	tower=5,
	king=6
};
struct node{
	TYPE tp;
	int hp,maxhp,arm;
	int reg,pos,str,weak,ero,rid;
}g[5][3];
bool game;
bool now,is_flush=0;
char me;
string info[1024],name[1024],skill[1024];
int cost[1024],E,rest=6;
vector<int> card;
bool endflag;
int timer=0;

BOOL WINAPI ConsoleHandlerRoutine(DWORD dwCtrlType) {
    switch (dwCtrlType) {
        case CTRL_CLOSE_EVENT:{
        	char data[1024];
        	data[0]='L';
        	send(sock,data,1024,0);
        	return TRUE;
		}
        default:
            return FALSE;
    }
}
void cleanup(){
	char data[1024];
	data[0]='L';
	send(sock,data,1024,0);
}

inline string tostr(int x){
	stringstream sstream;
	sstream<<x;
	string s;
	sstream>>s;
	return s;
}
inline int toint(string x){
	stringstream sstream;
	sstream<<x;
	int ret;
	sstream>>ret;
	return ret;
}
inline void init(){
	fstream file;
	file.open("card.txt",ios::in|ios::binary);
	if(file.is_open()){
		int cnt=1;
		int flag=0;
		while(1){
			string s;
			if(!getline(file,s))break;
			while(s.back()=='\r')s.pop_back();
//			cout<<"read: ["<<s<<"]\n";
			if(s=="end"){
				++cnt;flag=0;continue;
			}else if(s=="name"){
				flag=1;continue;
			}else if(s=="cost"){
				flag=2;continue;
			}
			if(flag==0){
				name[cnt]=s;
			}else if(flag==1){
				cost[cnt]=toint(s);
			}else{
				s+='\n'; 
				info[cnt]+=s;
			}
//			cout<<name[cnt]<<"\n";
		}
	}
	file.close();
	file.open("skill.txt",ios::in|ios::binary);
	if(file.is_open()){
		int cnt=0;
		while(1){
			string s;
			if(!getline(file,s))break;
			while(s.back()=='\r')s.pop_back();
			if(s=="end"){
				++cnt;continue;
			}
			s+='\n';
			skill[cnt]+=s;
		}
	}
	file.close();
}
inline void list_card(){
	cout<<card.size()<<'\n';
	if(card.empty()){
		cout<<"[��]\n\n";return;
	}
	rep(i,0,(int)card.size()-1){
		cout<<i+1<<". "<<name[card[i]]<<"\n";
	}
	cout<<"\n";
}
inline void drawX(int x,int y,int W){
	line(x,y,x+W,y+W);
    line(x+W,y,x,y+W);
}
inline void drawO(int x,int y,int W){
	circle(x+W/2,y+W/2,W/2);
}
inline void drawxj(int x,int y,int W){
	circle(x+W/2,y+W/4,W/6);
	line(x+W/2,y+W/4+W/6,x+W/2,y+W/5*3);
	line(x+W/2,y+W/5*3,x+W/2-W/5,y+W/6*5);
	line(x+W/2,y+W/5*3,x+W/2+W/5,y+W/6*5);
	line(x+W/2,y+W/7*4,x+W/2-W/5,y+W/7*3);
	line(x+W/2,y+W/7*4,x+W/2+W/5,y+W/7*3);
	ellipse(x+W/2,y+(W/5*3+W/6*5)/2+W/10,0,360,W/4,W/7);
}
inline void drawjamie(int x,int y,int W){
	circle(x+W/2,y+W/4,W/6);
	line(x+W/2,y+W/4+W/6,x+W/2,y+W/5*3);
	line(x+W/2,y+W/5*3,x+W/2-W/5,y+W/6*5);
	line(x+W/2,y+W/5*3,x+W/2+W/5,y+W/6*5);
	line(x+W/2,y+W/7*4,x+W/2-W/5,y+W/7*3);
	line(x+W/2,y+W/7*4,x+W/2+W/5,y+W/7*3);
	line(x+W/2-W/5,y+W/7*3+W/30,x+W/2-W/5-W/12,y+W/7*2);
	outtextxy(x+W/2-W/5-W/12-W/7,y+W/7*2-W/7,"��");
}
inline void drawtower(int x,int y,int W){
	ellipse(x+W/5*2,y+W/5*2,0,360,W/6,W/8);
	setfillcolor(EGERGB(255,255,255));
	fillrect(x+W/5*2+W/6,y+W/5*2-1,x+W/5*4,y+W/5*2+1);
	setfillcolor(EGERGB(0,0,0));
	fillrect(x+W/5*2-W/6,y+W/5*2+W/8,x+W/3*2,y+W/5*4);
}
inline void flush(){
	if(is_flush)return;
	is_flush=1;
	cleardevice();
	setcolor(EGERGB(255,255,255));
    line(50,50,50+WIDTH*3,50);
    line(50,50,50,50+WIDTH*5);
    line(50+WIDTH*3,50,50+WIDTH*3,50+WIDTH*5);
    line(50,50+WIDTH*5,50+WIDTH*3,50+WIDTH*5);
    rep(i,2,3){
    	line(50,50+WIDTH*i,50+WIDTH*3,50+WIDTH*i);
	}
	rep(i,1,2){
    	line(50+WIDTH*i,50,50+WIDTH*i,50+WIDTH*5);
	}
	setcolor(EGERGB(255,0,0));
	line(50,50+WIDTH,50+WIDTH*3,50+WIDTH);
	line(50,50+WIDTH*4,50+WIDTH*3,50+WIDTH*4);
	line(50,50,50+WIDTH*3,50);
	line(50,50+WIDTH*5,50+WIDTH*3,50+WIDTH*5);
	rep(i,0,3)line(50+WIDTH*i,50,50+WIDTH*i,50+WIDTH);	
	rep(i,0,3)line(50+WIDTH*i,50+WIDTH*4,50+WIDTH*i,50+WIDTH*5);
	setcolor(EGERGB(255,255,255));
	drawX(50+3*WIDTH+(WIDTH-XW)/2,50+(WIDTH-XW)/2,XW*0.7);
	drawO(50+3*WIDTH+(WIDTH-XW)/2,50+4*WIDTH+(WIDTH-XW)/2,XW*0.7);
    rep(i,0,4){
    	rep(j,0,2){
    		int y=50+i*WIDTH,x=50+j*WIDTH;
    		if(g[i][j].tp!=none){
    			setcolor(EGERGB(255,255,0));
    			outtextxy(x+ADD,y+ADD,("HP:"+tostr(g[i][j].hp)+" arm:"+tostr(g[i][j].arm)).c_str());
				setcolor(EGERGB(255,255,255));
			}
    		if(g[i][j].tp==XX){
    			drawX(x+(WIDTH-XW)/2,y+(WIDTH-XW)/2,XW);
			}else if(g[i][j].tp==OO){
				drawO(x+(WIDTH-XW)/2,y+(WIDTH-XW)/2,XW);
			}else if(g[i][j].tp==xj){
				drawxj(x+(WIDTH-XW)/3,y+(WIDTH-XW)/2,XW*1.3);
			}else if(g[i][j].tp==jamie){
				drawjamie(x+(WIDTH-XW)/3,y+(WIDTH-XW)/2,XW*1.5);
			}else if(g[i][j].tp==tower){
				drawtower(x+(WIDTH-XW)/2,y+(WIDTH-XW)/2,XW);
			}
			if(g[i][j].tp!=none){
				if(g[i][j].pos){
					setcolor(EGERGB(0,255,0));
	    			outtextxy(x+5,y+(WIDTH-XW)/2+XW+ADD,"��");
					setcolor(EGERGB(255,255,255));
				}
    			if(g[i][j].ero){
					setcolor(EGERGB(255,255,255));
	    			outtextxy(x+5+15,y+(WIDTH-XW)/2+XW+ADD,"ʴ");
					setcolor(EGERGB(255,255,255));
				}
				if(g[i][j].reg){
					setcolor(EGERGB(255,0,0));
	    			outtextxy(x+5+30,y+(WIDTH-XW)/2+XW+ADD,"��");
					setcolor(EGERGB(255,255,255));
				}
    			if(g[i][j].str){
					setcolor(EGERGB(60,137,203));
	    			outtextxy(x+5+45,y+(WIDTH-XW)/2+XW+ADD,"��");
					setcolor(EGERGB(255,255,255));
				}
				if(g[i][j].weak){
					setcolor(EGERGB(173, 70, 218));
	    			outtextxy(x+5+60,y+(WIDTH-XW)/2+XW+ADD,"��");
					setcolor(EGERGB(255,255,255));
				}
				if(g[i][j].rid){
					setcolor(EGERGB(0, 255, 255));
	    			outtextxy(x+5+75,y+(WIDTH-XW)/2+XW+ADD,"��");
					setcolor(EGERGB(255,255,255));
				}
			}
		}
	}
	setcolor(EGERGB(0,0,255));
	outtextxy(50,50+WIDTH*5+ADD,("����:"+tostr(E)+" ����:"+tostr(card.size())).c_str());
	setcolor(EGERGB(255,255,255));
	is_flush=0;
}
void net_read(SOCKET sock){
//	init();
	char recv_data[1024];
	while(true){
		while(recv(sock,recv_data,1024,0) > 0){
			if(recv_data[0]=='Q'){
				MessageBox(NULL,"���������ˣ�","��",MB_OK);
				exit(0);
			}else if(recv_data[0]=='S'){
				cout<<"��ʼ\n";
				game=1;
				me=recv_data[1];
				initgraph(WIDTH*5, WIDTH*7);
			}else if(recv_data[0]=='E'){
				game=0;
				if(recv_data[1]=='W'){
					MessageBox(NULL,"Ӯ����","Ӯ����",MB_OK);
					exit(0);
				}else if(recv_data[1]=='L'){
					MessageBox(NULL,"������","������",MB_OK);
					exit(0);
				}else if(recv_data[1]=='f'){
					cout<<"���ֵ��ˣ�\n";
				}else if(recv_data[1]=='D'){
					MessageBox(NULL,"ƽ�֣�","ƽ�֣�",MB_OK);
					exit(0);
				}else{
					cout<<recv_data[1]<<" Ӯ����\n";
				}
			}else if(recv_data[0]=='Y'){
				now=1;
			}else if(recv_data[0]=='O'){
				cout<<"�ȴ��Է����塭��\n";
			}else if(recv_data[0]=='V'){
				cout<<"��ս�С���\n";
			}else if(recv_data[0]=='U'){
				memcpy(g,recv_data+1,sizeof(g));
				flush();
			}else if(recv_data[0]=='g'){
				int x;
				memcpy(&x,recv_data+1,4);
				E+=x;
			}else if(recv_data[0]=='p'){
				int x;
				memcpy(&x,recv_data+1,4);
				E-=x;
			}else if(recv_data[0]=='a'){
				int x;
				memcpy(&x,recv_data+1,4);
				card.eb(x);
			}else if(recv_data[0]=='d'){
				int x;
				memcpy(&x,recv_data+1,4);
				card.erase(card.begin()+x);
			}else if(recv_data[0]=='r'){
				cout<<recv_data[1]<<" ʹ���� [";
				int x;
				memcpy(&x,recv_data+2,4);
				cout<<name[x]<<"]��\n";
			}else if(recv_data[0]=='m'){
				char str[1024];
				memcpy(str,recv_data+1,1023);
				cout<<str<<"\n";
			}else if(recv_data[0]=='b'){
				endflag=1;
			}else if(recv_data[0]=='c'){
				endflag=0,timer=0;
			}
		}
	}
}

int main(){
	init();
	
//	g[1][1]={tower,1,1,1,1,1,1,1,1,1};
//	initgraph(WIDTH*5, WIDTH*7);
//	flush();
//	system("pause");
	
	if (!SetConsoleCtrlHandler(ConsoleHandlerRoutine, TRUE)){
		MessageBox(NULL,"����","��",MB_ICONERROR);return 0;
	}
	cout<<"������IP(IPv4):"<<"\n";
	cin>>addr;
	cout<<"�˿ڣ�"<<'\n';
	cin>>port;
	WSADATA wsa_data;
	WSAStartup(MAKEWORD(2, 2), &wsa_data);
	sock = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);  
	sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port);
	server_addr.sin_addr.s_addr = inet_addr(addr.c_str());
	if(connect(sock, (sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR){
		cerr<<"����\n";
		system("pause");
		return -1;
	}
	atexit(cleanup);
	thread t(net_read,sock);
	char send_data[1024];
	cout<<"���ڵȴ�������Ҽ��롭��\n";
	send_data[0]='J';
	send(sock,send_data,1024,0);
	while(true){
		if(now){
			system("pause");
			int x,y;
			while(1){
				system("cls");
				flush();
				cout<<"���壺������0 0��ʾ�����壩\n";
				if(endflag)cout<<"���������ս׶Σ��������3�غ����岻�¾ͻ����\n��Ŀǰ������"<<timer<<"�غϣ�\n";
				cin>>x>>y;
				if(x==0&&y==0){
					cout<<"��ѡ������\n";system("pause");
					if(endflag)++timer;
					if(!rest)timer=0;
					break;
				}
				if(2<=x&&x<=4&&1<=y&&y<=3&&g[x-1][y-1].tp==none){
					if(rest)--rest;
					else{
						cout<<"��û�������ˣ�\n";system("pause");
						continue;
					}
					if(me=='X'){
						g[x-1][y-1]={XX,4,4};
					}else{
						g[x-1][y-1]={OO,4,4};
					}
					timer=0;
					send_data[0]='x';
					send(sock,send_data,1024,0);
					break;
				}else{
					cout<<"����ط��������壡\n";system("pause");
				}
			}
			if(timer==3){
				send_data[0]='F';
				send(sock,send_data,1024,0);
			}
			send_data[0]='U';
			memcpy(send_data+1,g,sizeof(g));
			send(sock,send_data,1024,0);
			while(1){
				system("cls");
				flush();
				cout<<"�����еĿ��ƣ�\n";
				list_card();
				cout<<"��Ҫʹ�����ſ��ƣ�������\"? [���]\"�ɵ�����ϸ����������\"none\"�˳���\n";
				scanf("\n");
				string s;
				getline(cin,s);
				if(s=="none")break;
				int x;
				if(s[0]=='?'){
					string now="";
					rep(i,2,(int)s.size()-1){
						now.push_back(s[i]);
					}
					x=toint(now);
					if(x<1||x>card.size()){
						cout<<"��Чָ�\n";system("pause");continue;
					}
					cout<<name[card[x-1]]<<"��\n���ѣ�"<<cost[card[x-1]]<<"\n"<<info[card[x-1]]<<"\n";
					system("pause");
				}else{
					x=toint(s);
					if(x<1||x>card.size()||card[x-1]==13){
						cout<<"��Чָ�\n";system("pause");continue;
					}
					if(cost[card[x-1]]>E){
						cout<<"�������㣡\n";system("pause");continue;
					}
					send_data[0]='u';
					memcpy(send_data+1,&card[x-1],4);
					int TMP=x-1;
					memcpy(send_data+5,&TMP,4);
					if(card[x-1]==6||card[x-1]==2||card[x-1]==1||card[x-1]==14||card[x-1]==11||card[x-1]==12||card[x-1]==16){
						TMP=2;
						memcpy(send_data+9,&TMP,4);
						int x,y;
						while(1){
							cout<<"��Ҫ���ĸ���λʹ�ã�������0 0������ʹ�ã�\n";
							cin>>x>>y;
							if(x==0&&y==0){
								memcpy(send_data+13,&x,4);
								memcpy(send_data+17,&y,4);
								break;
							}
							if(x<1||y<1||x>5||y>3||g[x-1][y-1].tp==none){
								cout<<"��Чʹ�ã�\n";
//								cout<<g[x][y].tp<<"\n";
								continue;
							}
							memcpy(send_data+13,&x,4);
							memcpy(send_data+17,&y,4);
							break;
						}
					}else if(card[x-1]==15){
						TMP=2;
						memcpy(send_data+9,&TMP,4);
						int x,y;
						while(1){
							cout<<"��Ҫ���ĸ���λʹ�ã�������0 0������ʹ�ã�\n";
							cin>>x>>y;
							if(x==0&&y==0){
								memcpy(send_data+13,&x,4);
								memcpy(send_data+17,&y,4);
								break;
							}
							if(x<1||y<1||x>5||y>3||g[x-1][y-1].tp==none){cout<<"��Чʹ�ã�\n";continue;}
							if((me=='X'&&x==5)||(me=='O'&&x==1)||(me=='X'&&g[x-1][y-1].tp==OO)||(me=='O'&&g[x-1][y-1].tp==XX)){cout<<"��Чʹ�ã�\n";continue;}
							memcpy(send_data+13,&x,4);
							memcpy(send_data+17,&y,4);
							break;
						}
					}else if(card[x-1]==4){
						TMP=2;
						memcpy(send_data+9,&TMP,4);
						int x,y;
						while(1){
							cout<<"��Ҫ���ĸ�λ��ʹ�ã�\n";
							cin>>x>>y;
							if(x<2||y<1||x>4||y>3||g[x-1][y-1].tp!=none){
								cout<<"��Чʹ�ã�\n";
//								cout<<g[x][y].tp<<"\n";
								continue;
							}
							memcpy(send_data+13,&x,4);
							memcpy(send_data+17,&y,4);
							break;
						}
					}else if(card[x-1]==7||card[x-1]==8||card[x-1]==17){
						TMP=2;
						memcpy(send_data+9,&TMP,4);
						int x,y;
						while(1){
							cout<<"��Ҫ���ĸ�λ�÷��ã���0 0���������ã�\n";
							cin>>x>>y;
							if(x==0&&y==0){
								memcpy(send_data+13,&x,4);
								memcpy(send_data+17,&y,4);
								break;
							}
							if(x<1||y<1||x>5||y>3||g[x-1][y-1].tp!=none){
								cout<<"��Ч���ã�\n";
//								cout<<g[x][y].tp<<"\n";
								continue;
							}
							if((me=='X'&&x!=1)||(me=='O'&&x!=5)){
								cout<<"��Ч���ã�\n";
//								cout<<g[x][y].tp<<"\n";
								continue;
							}
							memcpy(send_data+13,&x,4);
							memcpy(send_data+17,&y,4);
							break;
						}
					}else if(card[x-1]==20){
						TMP=2;
						memcpy(send_data+9,&TMP,4);
						int x,y;
						while(1){
							cout<<"����ĸ���λ�������Ͻǣ�������0 0������ʹ�ã�\n";
							cin>>x>>y;
							if(x==0&&y==0){
								memcpy(send_data+13,&x,4);
								memcpy(send_data+17,&y,4);
								break;
							}
							if(x<1||y<1||x>=5||y>=3){
								cout<<"��Чʹ�ã�\n";
//								cout<<g[x][y].tp<<"\n";
								continue;
							}
							memcpy(send_data+13,&x,4);
							memcpy(send_data+17,&y,4);
							break;
						}
					}else{
						TMP=0;
						memcpy(send_data+9,&TMP,4);
					}
					cout<<"��ʹ���� "<<name[card[x-1]]<<" ��\n\n";
					send(sock,send_data,1024,0);
					E-=cost[card[x-1]];
					card.erase(card.begin()+x-1);
					flush(); 
					system("pause");
				}
			}
			set< pair<int,int> > ST;
			while(1){
				int XXX,YYY;
				system("cls");
				cout<<"��Ҫ���ĸ���λ����/ʹ�ü��ܣ�������0 0��ʾ������\n";
				cin>>x>>y;
				XXX=x,YYY=y;
				if(x==0&&y==0)break;
				if(x<1||y<1||x>5||y>3||g[x-1][y-1].tp==none){
					cout<<"��Ч���룡\n";system("pause");continue;
				}
				if((me=='X'&&x==5)||(me=='O'&&x==1)){
					cout<<"��Ч���룡\n";system("pause");continue;
				}
				if(ST.find(make_pair(x,y))!=ST.end()){
					cout<<"�õ�λʹ�ù��ˣ�\n";system("pause");continue;
				}
				if(g[x-1][y-1].tp==jamie){
					cout<<skill[jamie]<<'\n';
					int id;
					cout<<"ʹ���ĸ����ܣ�\n";
					cin>>id;
					if(id<1||id>3){
						cout<<"��Ч���룡\n";system("pause");continue;
					}
					bool ridf=0;
					rep(i,0,4){
						rep(j,0,2){
							if((me=='X'&&i==0)||(me=='O'&&i==4))continue;
							if((me=='X'&&g[i][j].tp==XX)||(me=='O'&&g[i][j].tp==OO))continue;
							if(g[i][j].rid){ridf=1;break;}
						}
					}
					memcpy(send_data+1015,&XXX,4);memcpy(send_data+1019,&YYY,4);
					if(id==1){
						int tmp;
						cout<<"���У�1�������У�2��ʹ�ã�\n";
						cin>>tmp;
						if(tmp==1){
							cout<<"���У�\n";
							cin>>tmp;
							if(tmp<1||tmp>5){cout<<"��Ч���룡\n";system("pause");continue;}
							if(ridf){
								bool flag=1;
								rep(j,0,2){
									if((me=='X'&&tmp==1)||(me=='O'&&tmp==5))break;
									if((me=='X'&&g[tmp-1][j].tp==XX)||(me=='O'&&g[tmp-1][j].tp==OO))continue;
									if(g[tmp-1][j].rid){flag=0;break;}
								}
								if(flag){cout<<"�����г�����λ��\n";system("pause");continue;}
							}
							send_data[0]='j';
							int ttttt=1;
							memcpy(send_data+1,&ttttt,4);
							memcpy(send_data+5,&ttttt,4);
							memcpy(send_data+9,&tmp,4);
							send(sock,send_data,1024,0);
							send_data[0]='m';
							string s;s+=me;
							s+=string(" ��Jamie�ڵ�")+tostr(tmp)+"��ʹ���˼���1��\0";
							memcpy(send_data+1,s.c_str(),s.size());send(sock,send_data,1024,0);ST.insert(make_pair(XXX,YYY));
						}else if(tmp==2){
							cout<<"���У�\n";
							cin>>tmp;
							if(tmp<1||tmp>5){cout<<"��Ч���룡\n";system("pause");continue;}
							if(ridf){
								bool flag=1;
								rep(i,0,4){
									if((me=='X'&&i==0)||(me=='O'&&i==4))continue;
									if((me=='X'&&g[i][tmp-1].tp==XX)||(me=='O'&&g[i][tmp-1].tp==OO))continue;
									if(g[i][tmp-1].rid){flag=0;break;}
								}
								if(flag){cout<<"�����г�����λ��\n";system("pause");continue;}
							}
							send_data[0]='j';
							int ttttt=1;
							memcpy(send_data+1,&ttttt,4);ttttt=2;
							memcpy(send_data+5,&ttttt,4);
							memcpy(send_data+9,&tmp,4);
							send(sock,send_data,1024,0);
							send_data[0]='m';
							string s;s+=me;
							s+=string(" ��Jamie�ڵ�")+tostr(tmp)+"��ʹ���˼���1��\0";
							memcpy(send_data+1,s.c_str(),s.size());send(sock,send_data,1024,0);ST.insert(make_pair(XXX,YYY));
						}else{
							cout<<"��Ч���룡\n";system("pause");continue;
						}
					}else if(id==2){
						cout<<"���ĸ���λʹ�ã�\n";
						cin>>x>>y;
						if(x<1||x>5||y<1||y>3||g[x-1][y-1].tp==none){cout<<"��Ч���룡\n";system("pause");continue;}
						if(ridf){
							if((me=='X'&&x==1)||(me=='O'&&x==5)){cout<<"�����г�����λ��\n";system("pause");continue;}
							if((me=='X'&&g[x-1][y-1].tp==XX)||(me=='O'&&g[x-1][y-1].tp==OO)){cout<<"�����г�����λ��\n";system("pause");continue;}
							if(!g[x-1][y-1].rid){cout<<"�����г�����λ��\n";system("pause");continue;}
						}
						send_data[0]='j';
						int ttttt=2;
						memcpy(send_data+1,&ttttt,4);
						memcpy(send_data+5,&x,4);
						memcpy(send_data+9,&y,4);
						send(sock,send_data,1024,0);
						send_data[0]='m';
						string s;s+=me;
						s+=" ��Jamieʹ���˼���2��\0";
						memcpy(send_data+1,s.c_str(),s.size());send(sock,send_data,1024,0);ST.insert(make_pair(XXX,YYY));
					}else if(id==3){
						cout<<"���ĸ���λʹ�ã�\n";
						cin>>x>>y;
						if(x<1||x>5||y<1||y>3||g[x-1][y-1].tp==none){cout<<"��Ч���룡\n";system("pause");continue;}
						if(ridf){
							if((me=='X'&&x==1)||(me=='O'&&x==5)){cout<<"�����г�����λ��\n";system("pause");continue;}
							if((me=='X'&&g[x-1][y-1].tp==XX)||(me=='O'&&g[x-1][y-1].tp==OO)){cout<<"�����г�����λ��\n";system("pause");continue;}
							if(!g[x-1][y-1].rid){cout<<"�����г�����λ��\n";system("pause");continue;}
						}
						send_data[0]='j';
						int ttttt=3;
						memcpy(send_data+1,&ttttt,4);
						memcpy(send_data+5,&x,4);
						memcpy(send_data+9,&y,4);
						send(sock,send_data,1024,0);
						send_data[0]='m';
						string s;s+=me;
						s+=" ��Jamieʹ���˼���3��\0";
						memcpy(send_data+1,s.c_str(),s.size());send(sock,send_data,1024,0);ST.insert(make_pair(XXX,YYY));
					}
					system("pause");
				}else if(g[x-1][y-1].tp==tower){
					cout<<skill[tower]<<'\n';
					cout<<"���ĸ���λ������\n";
					bool ridf=0;
					rep(i,0,4){
						rep(j,0,2){
							if((me=='X'&&i==0)||(me=='O'&&i==4))continue;
							if((me=='X'&&g[i][j].tp==XX)||(me=='O'&&g[i][j].tp==OO))continue;
							if(g[i][j].rid){ridf=1;break;}
						}
					}
					cin>>x>>y;
					if(x<1||x>5||y<1||y>3||g[x-1][y-1].tp==none){cout<<"��Ч���룡\n";system("pause");continue;}
					if(ridf){
						if((me=='X'&&x==1)||(me=='O'&&x==5)){cout<<"�����г�����λ��\n";system("pause");continue;}
						if((me=='X'&&g[x-1][y-1].tp==XX)||(me=='O'&&g[x-1][y-1].tp==OO)){cout<<"�����г�����λ��\n";system("pause");continue;}
						if(!g[x-1][y-1].rid){cout<<"�����г�����λ��\n";system("pause");continue;}
					}
					send_data[0]='t';
					memcpy(send_data+1015,&XXX,4);memcpy(send_data+1019,&YYY,4);
					memcpy(send_data+1,&x,4);memcpy(send_data+5,&y,4);
					send(sock,send_data,1024,0);
					send_data[0]='m';
					string s;s+=me;
					s+=" ���Զ���̨�����˹�����\0";
					memcpy(send_data+1,s.c_str(),s.size());send(sock,send_data,1024,0);ST.insert(make_pair(XXX,YYY));
					system("pause");
				}else{
					cout<<"�˵�λ�޷�����/ʹ�ü��ܣ�\n";system("pause");continue;
				}
			}
			now=0; 
			send_data[0]='e';
			send(sock,send_data,1024,0);
		}
//		send(sock,send_data,1024,0);
	}
	return 0;
}
