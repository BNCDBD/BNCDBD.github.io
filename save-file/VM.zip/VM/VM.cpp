#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define rep(i,x,y) for(int i=(x);i<=(y);++i)
#define down(i,x,y) for(int i=(x);i>=(y);--i)
#define pii pair<int,int>
#define pll pair<ll,ll>
#define pil pair<int,ll>
#define pli pair<ll,int>
#define mkp make_pair
#define fi first
#define il inline
#define se second
#define eb emplace_back
#define pb push_back

#define FUNCTION_NOT_FOUND 0xce000001
#define CANNOT_READ_FILE 0xce000002

#define DIVISION_BY_ZERO 0xbd000001
#define UNKNOWN_CODE 0xbd000002

using namespace std;
enum BYTE_CODE{
	LEA,
	LI,
	SI,
	PUSH,
	OUTPUT,
	JMP,
	OR,
	AND,
	XOR,
	NOT,
	EQ,
	NEQ,
	LE,
	LT,
	GE,
	GT,
	ADD,
	SUB,
	MUL,
	DIV,
	MOD,
	SHL,
	SHR,
	NEG,
	EXIT,
	INPUT,
	REA,
	LOAD,
	BZ,
	MOV,
	CALL,
	LEAP,
	LP
};
template<size_t MEM_SIZE,size_t CODE_LEN>
class VM{
	ll mem[MEM_SIZE],code[CODE_LEN];
	public:
	ll Load(){
		map<string,ll*> func;
		map<string,int> args;
		printf("----------Load Mode----------\n");
		printf("File: ");
		string fi;
		getline(cin,fi);
		fstream file;
		file.open(fi,ios::in|ios::binary);
		if(!file.is_open()){
			printf("Failed to read.\n");return CANNOT_READ_FILE;
		}
		printf("Loading....\n");
		string s;
		ll* pc=code;
		bool ign=0;
		while(file>>s){
			string tmp,cont;
			for(char c:s){
				if(c=='$'){
					ign^=1;
				}else if(!ign){
					tmp.pb(c);
				}else if(ign){
					cont.pb(c);
				}
			}
			if(cont.size())cout<<cont<<'\n';
			s=tmp;
			if(s.empty())continue;
			if(s=="func"){
				ll x;
				string name;file>>name>>x;
				func[name]=pc;args[name]=x;
				printf("Function: ");cout<<name<<"("<<x<<")\n";
				continue;
			}
			printf("(+%lld): ",(ll)(pc-code));
			cout<<s<<'\n';
			if(s=="lea"){
				*pc++=LEA;
				ll x;file>>x;*pc++=x;
			}else if(s=="li"){
				*pc++=LI;
			}else if(s=="si"){
				*pc++=SI;
			}else if(s=="push"){
				*pc++=PUSH;
			}else if(s=="output"){
				*pc++=OUTPUT;
			}else if(s=="jmp"){
				*pc++=JMP;
				ll x;file>>x;*pc++=x;
			}else if(s=="or"){
				*pc++=OR;
			}else if(s=="and"){
				*pc++=AND;
			}else if(s=="xor"){
				*pc++=XOR;
			}else if(s=="not"){
				*pc++=NOT;
			}else if(s=="eq"){
				*pc++=EQ;
			}else if(s=="neq"){
				*pc++=NEQ;
			}else if(s=="lt"){
				*pc++=LT;
			}else if(s=="le"){
				*pc++=LE;
			}else if(s=="gt"){
				*pc++=GT;
			}else if(s=="ge"){
				*pc++=GE;
			}else if(s=="add"){
				*pc++=ADD;
			}else if(s=="sub"){
				*pc++=SUB;
			}else if(s=="mul"){
				*pc++=MUL;
			}else if(s=="div"){
				*pc++=DIV;
			}else if(s=="mod"){
				*pc++=MOD;
			}else if(s=="shl"){
				*pc++=SHL;
			}else if(s=="shr"){
				*pc++=SHR;
			}else if(s=="neg"){
				*pc++=NEG;
			}else if(s=="exit"){
				*pc++=EXIT;
			}else if(s=="input"){
				*pc++=INPUT;
			}else if(s=="rea"){
				*pc++=REA;
				ll x;file>>x;*pc++=x;
			}else if(s=="load"){
				*pc++=LOAD;
				ll x;file>>x;*pc++=x;
			}else if(s=="bz"){
				*pc++=BZ;
				ll x;file>>x;*pc++=x;
			}else if(s=="mov"){
				*pc++=MOV;
				ll x,y;file>>x>>y;*pc++=x,*pc++=y;
			}else if(s=="call"){
				*pc++=CALL;
				string name;file>>name;
				if(func.find(name)==func.end()){
					printf("Error: Function not found:\"%s\"\n",name.c_str());
					return FUNCTION_NOT_FOUND;
				}
				*pc++=(ll)func[name];
				*pc++=args[name];
			}else if(s=="leap"){
				*pc++=LEAP;
				ll x;file>>x;*pc++=x;
			}else if(s=="lp"){
				*pc++=LP;
				ll x;file>>x;*pc++=x;
			}
		}
		if(func.find("main")==func.end()){
			printf("Error: Function not found:\"main\"\n");
			return FUNCTION_NOT_FOUND;
		}
		printf("Load Successfully\n");
		printf("-------------End-------------\n");
		return (ll)func["main"];
	}
	int Run(ll* Start){
		ll *pc=Start,*tp=mem+MEM_SIZE,*bp=tp,tmp,tmp2;
		--bp;
		ll rx[8];
		while(true){
			ll command=*pc++;
			switch(command){
				case LEA:rx[0]=(ll)(bp-*pc++);break;
				case LI:rx[0]=*(ll*)rx[0];break;
				case SI:*(ll*)(*tp++)=rx[0];break;
				case PUSH:*--tp=rx[0];break;
				case OUTPUT:putchar(rx[0]);break;
				case JMP:pc=code+*pc;break;
				case OR:rx[0]=rx[0]|(*tp++);break;
				case AND:rx[0]=rx[0]&(*tp++);break;
				case XOR:rx[0]=rx[0]^(*tp++);break;
				case NOT:rx[0]=~rx[0];break;
				case EQ:rx[0]=(rx[0]==(*tp++));break;
				case NEQ:rx[0]=(rx[0]!=(*tp++));break;
				case LT:rx[0]=(rx[0]<(*tp++));break;
				case LE:rx[0]=(rx[0]<=(*tp++));break;
				case GT:rx[0]=(rx[0]>(*tp++));break;
				case GE:rx[0]=(rx[0]>=(*tp++));break;
				case ADD:rx[0]=(rx[0]+(*tp++));break;
				case SUB:rx[0]=(rx[0]-(*tp++));break;
				case MUL:rx[0]=(rx[0]*(*tp++));break;
				case DIV:if(*tp==0)return DIVISION_BY_ZERO;rx[0]=(rx[0]/(*tp++));break;
				case MOD:if(*tp==0)return DIVISION_BY_ZERO;rx[0]=(rx[0]%(*tp++));break;
				case SHL:rx[0]=(rx[0]<<(*tp++));break;
				case SHR:rx[0]=(rx[0]>>(*tp++));break;
				case NEG:rx[0]=-rx[0];break;
				case EXIT:if(bp==mem+MEM_SIZE-1)return (int)rx[0];tp=bp,bp=(ll*)*(tp++),pc=(ll*)*tp++,*--tp=rx[0];break;
				case INPUT:rx[0]=getchar();break;
				case REA:tp=tp+(*pc++);break;
				case LOAD:rx[0]=(*pc++);break;
				case BZ:tmp=(*pc++),pc=(rx[0]?code+tmp:pc);break;
				case MOV:tmp=*pc++,tmp2=*pc++,rx[tmp2]=rx[tmp];break;
				case CALL:{tmp=*pc++,tmp2=*pc++;for(ll *i=tp;i<=tp-tmp2+1;++i)*(i-2)=*i;*(tp-tmp2-1)=(ll)pc,*(tp-tmp2)=(ll)bp,bp=tp-tmp2,tp=tp+2,pc=(ll*)tmp;break;}
				case LEAP:rx[0]=(*tp++)*(*pc++)+rx[0];break;
				case LP:rx[0]=(ll)(mem+MEM_SIZE-1-*pc++);break;
				default:return UNKNOWN_CODE;
			}
		}
	}
};
VM<(1<<20),(1<<12)> vm;
signed main(){
	ll* Start=(ll*)vm.Load();
	int ret=vm.Run(Start);
	printf("------------------------------\nVM exited with code %d.\n",ret);
	return 0;
}

